from flask import Flask, render_template, request, redirect
import mysql.connector


app = Flask(__name__)

db_config = {
    "host": "localhost",
    "user": "root",
    "password": "0223",
    "database": "online_bookstore"
}

@app.route('/')
def index():
    return render_template('registration.html')

@app.route('/register', methods=['POST'])
def register():
    try:
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        password = request.form['password']
        verify_password = request.form['verify_password']

        if password != verify_password:
            return redirect('/?passwordNotMatch')
     
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        check_query = "SELECT customer_id FROM customers WHERE email = %s OR phone_no = %s"
        cursor.execute(check_query, (email, phone))
        existing_user = cursor.fetchone()

        if existing_user:
            return redirect('/?existingUser')

        insert_query = "INSERT INTO customers (customer_name, email, phone_no, address, password) VALUES (%s, %s, %s, %s, %s)"
        data = (name, email, phone, address, password)
        cursor.execute(insert_query, data)

        connection.commit()
        cursor.close()
        connection.close()
        return render_template('login.html')

    except mysql.connector.Error as err:
        return "Error: " + str(err)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email_phone = request.form['email_phone']
        password = request.form['password']

        try:
            connection = mysql.connector.connect(**db_config)
            cursor = connection.cursor()

            select_query = "SELECT * FROM customers WHERE email = %s OR phone_no = %s"
            cursor.execute(select_query, (email_phone, email_phone))
            user_data = cursor.fetchone()

            if user_data:
                if password == user_data[5]:
                    return render_template('dashboard.html')
                else:
                    return redirect('/login?incorrectPassword')
            else:
                return redirect('/login?invalidUser')

        except mysql.connector.Error as err:
            return "Error: " + str(err)

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')


@app.route('/payment')
def payment():
    return render_template('payment.html')

@app.route('/process_payment', methods=['POST'])
def process_payment():
    try:
        card_number = request.form['card_number']
        expiration_date = request.form['expiration_date']
        cvv = request.form['cvv']

        
        return render_template('thank_you.html')

    except Exception as e:
        return "Payment failed. Error: " + str(e)

if __name__ == '__main__':
    app.run(debug=True)
